# regmodels

A simple yet powerful library to compare multiple regression models visually and statistically.

## Installation
```bash
pip install regmodels
